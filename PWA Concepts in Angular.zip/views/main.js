search = () => {
    nullify()
    let emp = document.getElementById("empId").value
    if (emp) {
        fetch("http://localhost:4800/employee/" + emp).then((data) => {
            if (data.status == 200) {
                data.json().then((data) => {
                    let empData = data
                    let tech = ""
                    empData.technology.forEach(element => {
                        tech += `<li>${element}</li>`
                    });
                    let detail = `
                        <div class="col-md-6 offset-3 card">
                            <div class = "card-body">
                                <div class = "form-group">
                                    <label>Employee Id:</label>${empData.empId}
                                </div>
                                <div class = "form-group">
                                    <label>Employee Name:</label>${empData.empName}
                                </div>
                                <div class = "form-group">
                                    <label>Employee Role:</label>${empData.role}
                                </div>
                                <div class = "form-group">
                                    <label>Technology:</label><br>${tech}
                                </div>
                                <div class = "form-group">
                                    <button class = "btn btn-danger" onclick="exit()">close</button>
                                </div>
                            </div>
                        </div>
                    `
                    document.getElementById("detail").innerHTML = detail


                })

            } else {
                data.json().then((err) => {
                    document.getElementById("detail").innerHTML =  errTag(err)
                })
            }
        }).catch((err) => {
            document.getElementById("detail").innerHTML =  errTag(err)
        })
    } else {
        
        document.getElementById("detail").innerHTML = errTag(new Error("Please enter a employee id"))
    }
    return false
}

getDetails = () => {
    nullify()
    fetch("http://localhost:4800/employee").then((data) => {
        if (data.status == 200) {
            let row = `<tr>
            <th>
                Employee Id
            </th>
            <th>
            Employee Name
            </th>
            <th>
           Role
            </th>
            <th>
            Technology
            </th>
        </tr>`
            data.json().then((empDetails) => {
                empDetails.forEach((emp) => {
                    row += `<tr>
                        <td>
                            ${emp.empId}
                        </td>
                        <td>
                        ${emp.empName}
                        </td>
                        <td>
                        ${emp.role}
                        </td>
                        <td>
                        ${emp.technology}
                        </td>
                    </tr>`
                })
                document.getElementById("empArr").innerHTML = `<table class="table table-bordered">${row}</table>`
            })
        } else {
            data.json().then((error) => {
                document.getElementById("empArr").innerHTML = errTag(error)
            })
        }
    }).catch((err) => {
        err = new Error("You seem to be offline")
        document.getElementById("empArr").innerHTML =  errTag(err);
    })
}

nullify = () => {
    document.getElementById("empArr").innerHTML = null
    document.getElementById("detail").innerHTML = null
}

errTag = (msg)=>`<div class="text-danger">${msg.message}</div>`



// updateFound = () => {
//     let event = new CustomEvent("update")
//     document.getElementById("new_version").dispatchEvent(event)
// }

document.getElementById('new_version').style.visibility = 'hidden'

let btnAdd = document.getElementById("btnAdd")
btnAdd.style.display = "none"

let deferredPrompt


if (!window.matchMedia('(display-mode: standalone)').matches) {
    console.log('display-mode is standalone');
    window.addEventListener('beforeinstallprompt', (e) => {
        e.preventDefault();
        deferredPrompt = e;
        btnAdd.style.display = 'block';
    });
}
let addTo = document.getElementById("addTo")
addTo.addEventListener('click', (e) => {
    btnAdd.style.display = 'none';
    deferredPrompt.prompt()
       deferredPrompt.userChoice
        .then((choiceResult) => {
            if (choiceResult.outcome === 'accepted') {
                console.log('Application added to Home Screen');
            } else {
                console.log('User denied Adding to Home Screen');
            }
            deferredPrompt = null;
        });
});
let cancelbtn = document.getElementById("cancel")
cancelbtn.addEventListener("click",(e)=>{
    btnAdd.style.display = 'none';
})
window.addEventListener('appinstalled', (evt) => {
    app.logEvent('a2hs', 'installed');
});
