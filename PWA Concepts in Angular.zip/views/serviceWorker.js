const CACHE_STATIC_NAME = "pre-cache-v-10.0";

// When we make any change to the cached resources, it will not be visible to the end user as the resource is still being served from the cache itself. This problem is called as cache invalidation. How to remove resources from the cache and add new resources to the cache?

// This involves 4 steps: 

// 1. For every change in the cache resource, update the version number of the cache name.

// 2. This will ensure that the service worker is changed and will result in the new service worker getting installed.

// 3. When an updated or new service worker gets installed, a new cache is generated and updated resource will be added to the cache.

// 4. In the ‘activate’ event listener, delete all the old cache except the current one. This will ensure that the old version of the cache is not used and the new one is used.


const Dynamic_cache = "dynamic-cache";





let cacheURL = [
    '/',
    'https://code.jquery.com/jquery-3.3.1.slim.min.js',
    'https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js',
    'https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css',
    // 'https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css',
    'style.css',
    'index.html',
    'contact.html',
    'main.js'
];

self.addEventListener("message", event => {
    self.skipWaiting()
})


self.addEventListener('fetch', event => {
    console.log(' Dynamic Fetching from service worker ')
    event.respondWith(
        caches.match(event.request).then((response) => {
            if (response) {
                return response
            } else {
                return fetch(event.request).then((response) => {
                    return caches.open(Dynamic_cache).then((cache) => {
                        let responseToCache = response.clone()
                        cache.put(event.request, responseToCache)
                        return response
                    })
                })
            }
        })
    )
})

self.addEventListener('fetch', event => {
    console.log('Fetching from service worker')
    event.respondWith(
        caches.match(event.request).then((response) => {
            if (response) {
                return response
            }
        })
    )
})

// self.addEventListener('fetch', event => {
//     // Prevent the default, and handle the request ourselves.
//     event.respondWith(async function() {
//       // Try to get the response from a cache.
//       const cachedResponse = await caches.match(event.request);
//       // Return it if we found one.
//       if (cachedResponse) return cachedResponse;
//       // If we didn't find a match in the cache, use the network.
//       return fetch(event.request);
//     }());
//   });

self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open(CACHE_STATIC_NAME)
            .then((cache) => {
                console.log('[Service Worker] - Precaching app shell');
                cache.addAll(cacheURL);
            })
    );
});



self.addEventListener('activate', event => {
    console.log('Activating the service worker');
    event.waitUntil(
      caches.keys().then(keys => Promise.all(
        keys.map(key => {
          if (key!=CACHE_STATIC_NAME) {
            return caches.delete(key);
          }
        })
      )).then(() => {
        console.log('Cache updated!');
      })
    );
  })


// self.addEventListener('activate', (event) => {
//     console.log(`[Service worker] - ${event.type} service worker.... `);
//     return self.clients.claim();
// });
// self.addEventListener('fetch', event => {
//     console.log('Fetching from service worker')
//     event.respondWith(
//         caches.match(event.request).then((response) => {
//             if (response) {
//                 return response
//             }
//         })
//     )
// })
// self.addEventListener('fetch', function(event) {
//     console.log('Fetching from service worker')
//     event.respondWith(
//       fetch(event.request).catch(function() {
//         return caches.match(event.request);
//       })
//     );
//   });



// self.addEventListener('fetch', event => {
//     // Prevent the default, and handle the request ourselves.
//     event.respondWith(async function() {
//       // Try to get the response from a cache.
//       const cachedResponse = await caches.match(event.request);
//       // Return it if we found one.
//       if (cachedResponse) return cachedResponse;
//       // If we didn't find a match in the cache, use the network.
//       return fetch(event.request);
//     }());
//   });